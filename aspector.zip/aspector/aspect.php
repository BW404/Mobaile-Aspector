
<style>
	#aspect_main{
		width:100%;
		height:100%;
		background:white;
		position:fixed;
		top:0px;
		transition:0.6s;
		left:-100%;
		z-index:calc(9 * 9);
	}
	#aspect_main textarea{
		width:100%;
		height:calc(100% - 80px);
		background:white;
		/* margin-top:80px; */
		border:2px solid silver;
		padding:15px;
		box-sizing:border-box;
		font-family:sens-serif;
		font-size:1.3em;
	}
	#aspect_main #top_bar{
		width:100%;
		height:80px;
		background:rgba(0,0,0,0.1);
	}
	#aspect_main #top_bar{
		width:100%;
		height:80px;
		background:rgba(0,0,0,0.01);
		position:relative;
	}
	#aspect_main #top_bar a{
		width:100%;
		height:80px;
		font-size:2.7em;
		text-decoration:none;
		color:black;
		display:flex;
		align-items:center;
		justify-content:flex-start;
		padding-left:25px;
		box-sizing:border-box;
		font-weight:bold;
	}
	#aspect_main #top_bar span:nth-child(1){
		position:absolute;
		width:80px;
		display:flex;
		align-items:center;
		justify-content:center;
		height:80px;
		top:0px;
		right:110px;
		font-size:2.5em;
		background:rgba(0,0,0,0.1);
		color:rgba(0,0,0,0.7);
	}
	#aspect_main #top_bar span:nth-child(2){
		position:absolute;
		width:80px;
		display:flex;
		align-items:center;
		justify-content:center;
		height:80px;
		top:0px;
		right:20px;
		font-size:2em;
		background:rgba(0,0,0,0.1);
		color:rgba(0,0,0,0.7);
	}
	#aspect_range{
		height:100px;
		width:35px;
		position:fixed;
		top:0px;
		left:0px;
		opacity:0;
		background:red;
	}
</style>
<div id="aspect_main">
<p id="top_bar">
	<span onclick="aspect_cancel()">⨯</span>
	<span onclick="aspect_save()">☑</span>
	<a href="mailto:firejoy.coder@gmail.com"><p1  style="color:red;">A</p1>spector</a>
</p>
	<textarea id="aspect_data"></textarea>
</div>
<input type="range" value="0" min="0" max="100" oninput="aspect_start(this)" id="aspect_range" ontouchend="aspect_ranger_end(this)">
<input type="hidden" id="aspect_data" value="0">
<script>
function aspect_start(data){
	data.style.width="100%";
	if(data.value>=50){
		var main=document.querySelector("#aspect_main");
		main.style.left="0%";
		var data=document.querySelector("#aspect_data");
		data.value=document.body.innerHTML;

	}
}
// aspect start
function aspect_ranger_end(data){
		data.style.width="35px";
}
// ranger touch end
function aspect_cancel(){
	var main=document.querySelector("#aspect_main").style.left="-100%";

}
// aspect cancel
function aspect_save(){
	var data=document.querySelector("#aspect_data");
	document.body.innerHTML=data.value;
	var main=document.querySelector("#aspect_main");
	main.style.left="0%";
}
</script>
